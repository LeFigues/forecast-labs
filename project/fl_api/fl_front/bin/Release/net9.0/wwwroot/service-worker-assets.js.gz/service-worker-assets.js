self.assetsManifest = {
  "version": "1JSk3DW4",
  "assets": [
    {
      "hash": "sha256-We76yQ6BbUqy3OL7pB4AiChSOtAH/BdDsZ0Z+MzXvD0=",
      "url": "_content/Blazor-ApexCharts/css/apexcharts.css"
    },
    {
      "hash": "sha256-nv9+cClODqGzZRotZMRKCqU9Wl7Hl8L+Tyr7WF1h3v0=",
      "url": "_content/Blazor-ApexCharts/js/apexcharts.esm.js"
    },
    {
      "hash": "sha256-sLy8ciMYC+0FnH+Ss8OYajbSQuC+9ejVj9It9yiBpYc=",
      "url": "_content/Blazor-ApexCharts/js/blazor-apexcharts.js"
    },
    {
      "hash": "sha256-dlafcjAJqs3GUdcc3mJSK86lwcZblr5It4eEvw4uLxs=",
      "url": "_content/Blazor-ApexCharts/locales/ar.json"
    },
    {
      "hash": "sha256-FzJo0NTrozXZ2X0k5cBHq23/cNsJsjzz8ro8AmmgIsM=",
      "url": "_content/Blazor-ApexCharts/locales/be-cyrl.json"
    },
    {
      "hash": "sha256-TBvJZemrAZAKyekGjuTHrZTH1It0sqSk5Sqz8yH9K0w=",
      "url": "_content/Blazor-ApexCharts/locales/be-latn.json"
    },
    {
      "hash": "sha256-Hy0vKUYq8y24J65z6P6BRt+pAJEStUUkq6h/wO8qGmI=",
      "url": "_content/Blazor-ApexCharts/locales/ca.json"
    },
    {
      "hash": "sha256-wKX1p4OPUkgraQA/lGUPFeTkjNfSDjk2BVoNpp3/rtw=",
      "url": "_content/Blazor-ApexCharts/locales/cs.json"
    },
    {
      "hash": "sha256-F4FSX9RRquRBpeWXM8Cy22+MiyvJ99Qln9osdCg9JrI=",
      "url": "_content/Blazor-ApexCharts/locales/da.json"
    },
    {
      "hash": "sha256-/Cw+PNZKKo3HojTIexT8ydZxxRVcJB/FibSNrmFMOBs=",
      "url": "_content/Blazor-ApexCharts/locales/de.json"
    },
    {
      "hash": "sha256-FCAyMj67tLnnn5Uu2HnYV2IPFm7NK6p2r8+7T5QnNoc=",
      "url": "_content/Blazor-ApexCharts/locales/el.json"
    },
    {
      "hash": "sha256-4r/u+pmflgFnRb/LLQj1UTO2uiLdwOZJXUEKZCMVq7U=",
      "url": "_content/Blazor-ApexCharts/locales/en.json"
    },
    {
      "hash": "sha256-5Arhr8jFsoVzlMD2BYO0QdEydcct2kjrXllGn2+ql2k=",
      "url": "_content/Blazor-ApexCharts/locales/es.json"
    },
    {
      "hash": "sha256-Wx99ItyPuJ/JHH4kZsfa31sf0/cPZ3RB2X3GYgVXzpo=",
      "url": "_content/Blazor-ApexCharts/locales/et.json"
    },
    {
      "hash": "sha256-5VsTIOaI9i/Kl2AE59RFVgnvO57ey5z4n7zEmDc7JLA=",
      "url": "_content/Blazor-ApexCharts/locales/fa.json"
    },
    {
      "hash": "sha256-5oebmtfJvQfIA0wtj/w1i/CdMxggN4N5KpIsBGPAzt0=",
      "url": "_content/Blazor-ApexCharts/locales/fi.json"
    },
    {
      "hash": "sha256-aRM0YbD29kxiOoWjBKwe//2ptq+Z58fpOKjmYlSXmRo=",
      "url": "_content/Blazor-ApexCharts/locales/fr.json"
    },
    {
      "hash": "sha256-DBPpL9k31pu/OonYe4MoNQXth8VYoGCaBohW/PVjxRQ=",
      "url": "_content/Blazor-ApexCharts/locales/he.json"
    },
    {
      "hash": "sha256-kka3njmet1llQ1oQUSWWGrfEV0Z+hVfdIykpRKFGeVU=",
      "url": "_content/Blazor-ApexCharts/locales/hi.json"
    },
    {
      "hash": "sha256-vJal2x2QNigFc1HPfraHPajLDa/+KYm6EX7/9OuIGuE=",
      "url": "_content/Blazor-ApexCharts/locales/hr.json"
    },
    {
      "hash": "sha256-D77nW8E9LACWcDLYiQi4tmABTzWdtQHiRIZh4dl/+u4=",
      "url": "_content/Blazor-ApexCharts/locales/hu.json"
    },
    {
      "hash": "sha256-kMokcniW/vMpTaZUExL0GjIglPOJROzCuz82Cdra9QM=",
      "url": "_content/Blazor-ApexCharts/locales/hy.json"
    },
    {
      "hash": "sha256-gh6YummZEUvK77HpqdCNf37hc0F+lhhqIRqhOEIU5do=",
      "url": "_content/Blazor-ApexCharts/locales/id.json"
    },
    {
      "hash": "sha256-HI8ky56OnvbeyCQXEcmb3DmtGeER9kGDff9kbvrjAXI=",
      "url": "_content/Blazor-ApexCharts/locales/it.json"
    },
    {
      "hash": "sha256-uKgcjn6aZkz865gYeSKNABrJ/0uOZji+DAyZ0FG6qLg=",
      "url": "_content/Blazor-ApexCharts/locales/ja.json"
    },
    {
      "hash": "sha256-nM5CmrAeofY0I2bHyyyZ9BQMmT8V7ZZ3Q98Gc5HsD/0=",
      "url": "_content/Blazor-ApexCharts/locales/ka.json"
    },
    {
      "hash": "sha256-oiRKl5wBbddidyXK+EdWR5/wQ5A+iIR2qgrN+iyghFw=",
      "url": "_content/Blazor-ApexCharts/locales/ko.json"
    },
    {
      "hash": "sha256-F5SN8qqGkcG7fv57T+BooYAzbWWddDQLZ0BZs0wuv14=",
      "url": "_content/Blazor-ApexCharts/locales/lt.json"
    },
    {
      "hash": "sha256-V3v5fb3Zoax8x3QuoG+gpIrCN8MFDX1V7jZo4TLOl2Q=",
      "url": "_content/Blazor-ApexCharts/locales/lv.json"
    },
    {
      "hash": "sha256-HCgQ1y0mMwXEulNPTZEWVN7VGkpgWMRn+nAvPRxVmdE=",
      "url": "_content/Blazor-ApexCharts/locales/ms.json"
    },
    {
      "hash": "sha256-wM4lkbC04I2/uPlIySZDlWSUS62IA0U81mD2U3l2m/s=",
      "url": "_content/Blazor-ApexCharts/locales/nb.json"
    },
    {
      "hash": "sha256-Xw7MULGUFCVWATdL+U+YF+DGr2+IJmrZml+tMj7uUc0=",
      "url": "_content/Blazor-ApexCharts/locales/nl.json"
    },
    {
      "hash": "sha256-z3Z4PsPf0abnHt54FB3hX97yeN9m8SM8aBltHUELYqk=",
      "url": "_content/Blazor-ApexCharts/locales/pl.json"
    },
    {
      "hash": "sha256-D9Hj2hy1KOq9dGLrGGe8ays1RSWMHlINH7h+4NLPs7g=",
      "url": "_content/Blazor-ApexCharts/locales/pt-br.json"
    },
    {
      "hash": "sha256-rRUDFC/Tqe7MUK5n/STmcacv2q72vRl1CwznzIge3pM=",
      "url": "_content/Blazor-ApexCharts/locales/pt.json"
    },
    {
      "hash": "sha256-UOFpsRzXznwnmB8j37FSNH9BrWmEZ7IZ7I2rX77eQ6g=",
      "url": "_content/Blazor-ApexCharts/locales/ru.json"
    },
    {
      "hash": "sha256-SAbJxRWu7j7hjsBir0RLboTcFVZkW1QS80tMQosrRSE=",
      "url": "_content/Blazor-ApexCharts/locales/sk.json"
    },
    {
      "hash": "sha256-dBDBm89BPi3Yixs8Hg3Ic6WTgmXPrF6lLAN4LnjfpCs=",
      "url": "_content/Blazor-ApexCharts/locales/sl.json"
    },
    {
      "hash": "sha256-zThOdwY6+2clLH8KQWon026rtzcxeK5ExNtfFpFAzGc=",
      "url": "_content/Blazor-ApexCharts/locales/sq.json"
    },
    {
      "hash": "sha256-7Ifns1BAaPzJaEyNSEaKFztIPE51+Oap9ld+tvhsrmg=",
      "url": "_content/Blazor-ApexCharts/locales/sr.json"
    },
    {
      "hash": "sha256-KjZiCGep+a8C8NTV1V+03cxMLbAEstpJjyB/wQ8/a/k=",
      "url": "_content/Blazor-ApexCharts/locales/sv.json"
    },
    {
      "hash": "sha256-bSK3XfeSUbX+8I38665w0rt/uoeAmVwxVAR0Q5rhCe8=",
      "url": "_content/Blazor-ApexCharts/locales/th.json"
    },
    {
      "hash": "sha256-AkvVJzV+wuv+30FI8s5j0p9bJP2JSvRFVEuZSYCvqdE=",
      "url": "_content/Blazor-ApexCharts/locales/tr.json"
    },
    {
      "hash": "sha256-aZ+JRp6SO22n09PyMVLrChX15KW9YCLZPZ0z8t0ZJlo=",
      "url": "_content/Blazor-ApexCharts/locales/uk.json"
    },
    {
      "hash": "sha256-vS1emPRJh7O8aN6ONvGi9WNlwfDGchjNHPFL2/lqdfM=",
      "url": "_content/Blazor-ApexCharts/locales/vi.json"
    },
    {
      "hash": "sha256-mhzhU9izYDiEk2Iq60zSikDxEp+rWnQKOAZ2G1BoKMg=",
      "url": "_content/Blazor-ApexCharts/locales/zh-cn.json"
    },
    {
      "hash": "sha256-9NsKdU5ha32NGIS0Hj6dBR0Cpr8hgAr2IZpXCzHZnsY=",
      "url": "_content/Blazor-ApexCharts/locales/zh-tw.json"
    },
    {
      "hash": "sha256-D4v010X8CCoMe8zntlzpDprIyK4M9AqiQGHOILoDMnk=",
      "url": "_content/Blazorise.Bootstrap/blazorise.bootstrap.css"
    },
    {
      "hash": "sha256-ptGtGKmCZslO1+8cnkHj0qmcIrApK/RCH8jjWbpZdZs=",
      "url": "_content/Blazorise.Bootstrap/blazorise.bootstrap.min.css"
    },
    {
      "hash": "sha256-Y0dc/LjhiRic00QP5Cj1+X9XjCi/0qIm/AYfiQHDsK0=",
      "url": "_content/Blazorise.Bootstrap/modal.js"
    },
    {
      "hash": "sha256-zgaTnBujt9NCvh+wDReSdd2XYEPR5lvQQvQGyfQHmF4=",
      "url": "_content/Blazorise.Bootstrap/tooltip.js"
    },
    {
      "hash": "sha256-1SioXe6wrk1AIkPuJuExT4BFmjq4jmgnWyCsIbNKf0I=",
      "url": "_content/Blazorise.Bootstrap5/blazorise.bootstrap5.css"
    },
    {
      "hash": "sha256-mO8PWmUrwppFuHrMQrZYfB50MVflIcyl3tMk+Gn6I+w=",
      "url": "_content/Blazorise.Bootstrap5/blazorise.bootstrap5.min.css"
    },
    {
      "hash": "sha256-YxHiyucE1Q9R7eoulHj6AUMm48OzceZn9yb5HF2dp34=",
      "url": "_content/Blazorise.Bootstrap5/modal.js"
    },
    {
      "hash": "sha256-zgaTnBujt9NCvh+wDReSdd2XYEPR5lvQQvQGyfQHmF4=",
      "url": "_content/Blazorise.Bootstrap5/tooltip.js"
    },
    {
      "hash": "sha256-38oEp5gswFTiw7jPLRStdGoo1LybXFKd6ouZioy3EsQ=",
      "url": "_content/Blazorise.Charts/charts.js"
    },
    {
      "hash": "sha256-xoTc7gWMXJGBZtVeiYKd2TKGGIVbLt9a99npzZY2eQU=",
      "url": "_content/Blazorise.Charts/utilities.js"
    },
    {
      "hash": "sha256-1BB7u9Dv4KPjJLI6yZYzVhS0giwx4piY74Fc/3gCTiM=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/css/all.css"
    },
    {
      "hash": "sha256-teON4y0UnyJj2Gol8NtuY0GOKW9cQvAE8a0Ve1Bi25Y=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/css/all.min.css"
    },
    {
      "hash": "sha256-goIyoSiP3pIfEr3yBK5JtYqzzyDjb/gmE7SrYUx0Xss=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-brands-400.eot"
    },
    {
      "hash": "sha256-mkNazkZoNdhnEeZR8T3e2yTvytU72mhJmOQaT72Ghn8=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-brands-400.svg"
    },
    {
      "hash": "sha256-5OdoB6IaKslj5wfd/7NiMoNhjAQ0VySya9wj0Nr9/eY=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-brands-400.ttf"
    },
    {
      "hash": "sha256-hI6JzzJVz8+vp3anASfspHp/R83QlVhOTeyTHvcSO1Q=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-brands-400.woff"
    },
    {
      "hash": "sha256-vMavvDJ8X91+gTf3z8oRRKdqJLg9M4zbeCu/TBuujLs=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-brands-400.woff2"
    },
    {
      "hash": "sha256-bgFZEoiUpCxGUcbyDs3UxY9xlBjqGTlbeWO/5IV4Uyo=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-regular-400.eot"
    },
    {
      "hash": "sha256-H6s8DlRfGTLsnkGnBYcPeYHQvjqLQWKoQ2dHj9n/H0g=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-regular-400.svg"
    },
    {
      "hash": "sha256-GmpZWgL5Po3urukCH4vQxdxDoXd8w56sQDVWoOBwCmk=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-regular-400.ttf"
    },
    {
      "hash": "sha256-W1GKPaBwaF4wNw0XAiX4ul1sditmDZW9nYrstvCYSyA=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-regular-400.woff"
    },
    {
      "hash": "sha256-+CwXtsukrlPRj0CrgGbuqD/6vp5zzmHfQDRAP7zWUmU=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-regular-400.woff2"
    },
    {
      "hash": "sha256-dJA+4wD6j/Yyva/xYa6C51/z1H5JIDmZLJSHMCEN578=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-solid-900.eot"
    },
    {
      "hash": "sha256-6ul7uo0rEY141EgX6pkDMwmeoXjebOoZ2ZerXNZlaCs=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-solid-900.svg"
    },
    {
      "hash": "sha256-+daTPQTFmkKsowvYjuw4u5y+tpsVR/1VDvc+ugvOeho=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-solid-900.ttf"
    },
    {
      "hash": "sha256-vvH8r45Pr0cGzVHhfzcwZv+hvcxpxuZNPzl3Oc6Xu9U=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-solid-900.woff"
    },
    {
      "hash": "sha256-HQ5sf2tAtiwQySlzntdrCtvZoIWRqpVpe2+ALE3Egk8=",
      "url": "_content/Blazorise.Icons.FontAwesome/v5/webfonts/fa-solid-900.woff2"
    },
    {
      "hash": "sha256-dAtCPbfCp1zLI3RCecBMRNzVjgsbxTkNxZRXweX9ZrA=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/css/all.css"
    },
    {
      "hash": "sha256-rg5QxNIB3AxrUBaFUnN28bETr0gCYc+wk2DCqMyvr1I=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/css/all.min.css"
    },
    {
      "hash": "sha256-8p//M0dH7H0wO/WBMc7d0o0b/elz6YHOcx4tK7k8xOY=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/webfonts/fa-brands-400.ttf"
    },
    {
      "hash": "sha256-M7xwmtt1cGtE4mmgpICf5YrvUUwc9qSs9YgnRNzlDGk=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/webfonts/fa-brands-400.woff2"
    },
    {
      "hash": "sha256-B5QTt2BhkeGjk7RnxqRn88Lum+3Yrn6YCpMTR1jF9Rw=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/webfonts/fa-regular-400.ttf"
    },
    {
      "hash": "sha256-OYofjVCKD4Iv4vjmp1uhzXWb/LzPH2tJsA2gQ3JVnso=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/webfonts/fa-regular-400.woff2"
    },
    {
      "hash": "sha256-8c4NoSoB9+wVrmnE7VSZnqh1vSNuYv71isTdvLObNno=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/webfonts/fa-solid-900.ttf"
    },
    {
      "hash": "sha256-H739W17rNlIC8wsEW/O6XmTM4N3fHFivdKT+sBWKA6I=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/webfonts/fa-solid-900.woff2"
    },
    {
      "hash": "sha256-EggvwKIX9EdQJNn+I5XQU+ZhQNC3syeCwc8q3Hwesck=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/webfonts/fa-v4compatibility.ttf"
    },
    {
      "hash": "sha256-731lWi5p2FPH390rbkFznRjRJ0MAQhwQTFdOPyNhw9s=",
      "url": "_content/Blazorise.Icons.FontAwesome/v6/webfonts/fa-v4compatibility.woff2"
    },
    {
      "hash": "sha256-m4ic6bApgizDNEe93SNXAl7cf9TV4gkOaeIwAlIZyIo=",
      "url": "_content/Blazorise/blazorise.css"
    },
    {
      "hash": "sha256-UwFaM6PwFvXXRHHWGK9DhaOKnK0wvSKVqCWHYaMudY4=",
      "url": "_content/Blazorise/blazorise.min.css"
    },
    {
      "hash": "sha256-XFStg2wgDFlwezaKFIkxxaupYPswlJBV9KGM4yzJad4=",
      "url": "_content/Blazorise/breakpoint.js"
    },
    {
      "hash": "sha256-JwLQBNcK8jOtOj+MqcT3nLKJI5hRD0jvffR7jfN0oEc=",
      "url": "_content/Blazorise/button.js"
    },
    {
      "hash": "sha256-Ixv4O0t21NpbZR6d0ORC1WkQHljTvIS5MBs3lRDN3No=",
      "url": "_content/Blazorise/closable.js"
    },
    {
      "hash": "sha256-CjcMUJfMsVGSTkYYdVtQ1170lo8DVLPiqcyYfegqd/4=",
      "url": "_content/Blazorise/colorPicker.js"
    },
    {
      "hash": "sha256-T3GylGdGWTc31ok/eodR4Xd5xpKuUmTLo/aeUZ8RA1Q=",
      "url": "_content/Blazorise/datePicker.js"
    },
    {
      "hash": "sha256-PCEbgO+xl0NGLQ0Q3Jqnx9q3/8Uj2s3YBssNZIIWdRg=",
      "url": "_content/Blazorise/dragDrop.js"
    },
    {
      "hash": "sha256-qQ9U6DMuO0F91WYe/PJNxO7ePhhzid1pMBnXSj2V4Bg=",
      "url": "_content/Blazorise/dropdown.js"
    },
    {
      "hash": "sha256-jljHmlpwSxdL/P0hMxcYhYtTaydwxOAho29txuIzjJA=",
      "url": "_content/Blazorise/fileEdit.js"
    },
    {
      "hash": "sha256-7lJMto8j5MclvZ9bM6Yga1py/xoxI7mr1aUP/biCRCU=",
      "url": "_content/Blazorise/filePicker.js"
    },
    {
      "hash": "sha256-ZLYn2QWI+oPVgB6Y2ufpCh+VtnkuSODjC00OtQsnUnk=",
      "url": "_content/Blazorise/floatingUi.js"
    },
    {
      "hash": "sha256-1QFWq96hhy/lUAVIFugIHQ2Xn2vYJ5PS3/jIf8fiSGo=",
      "url": "_content/Blazorise/inputMask.js"
    },
    {
      "hash": "sha256-SbE6iHao/RZBG4jNQ9alNEk+AsNkI95opgqJgCMYplo=",
      "url": "_content/Blazorise/io.js"
    },
    {
      "hash": "sha256-nUVB9un/1r3/IGZ7dmp/9wcReTZBU/44mRuB6GfPbmc=",
      "url": "_content/Blazorise/memoEdit.js"
    },
    {
      "hash": "sha256-9Vt15dPPV8LwcwyUfR+6Z3Kxy16ZM1NepeuUl0l99tg=",
      "url": "_content/Blazorise/numericPicker.js"
    },
    {
      "hash": "sha256-UL7yfMvnqDrtwAkFBxgGYL+5hCO9VDCJ94lmA5Ry130=",
      "url": "_content/Blazorise/observer.js"
    },
    {
      "hash": "sha256-IQzXgzcKgwEmYmv1kIwnMp/EVcSocKKneCQaUHzb09w=",
      "url": "_content/Blazorise/table.js"
    },
    {
      "hash": "sha256-UzY+zwu9BjvtnPCwr1FF5eIMYGat+QdkI851af1G4eE=",
      "url": "_content/Blazorise/textEdit.js"
    },
    {
      "hash": "sha256-/z7kNAcnzllfg/HxEPpf0fnn2IpUACYWcVwVa2oqnsA=",
      "url": "_content/Blazorise/theme.js"
    },
    {
      "hash": "sha256-sQtptCUv7NIR0TGo94Prny+5Slw330AOyEnEZN5lsr4=",
      "url": "_content/Blazorise/timePicker.js"
    },
    {
      "hash": "sha256-9EgKo/NULX1QjPkuxpOxI+ssPj0Go1RYbOz43u5GfKw=",
      "url": "_content/Blazorise/tooltip.js"
    },
    {
      "hash": "sha256-3Ne2fqmXki6oKS25chdL6tXaKEpLlxyJynLHDivF1E0=",
      "url": "_content/Blazorise/utilities.js"
    },
    {
      "hash": "sha256-6VFRpMupxoUE443D30s91C5bFZsQ58DxuiNwbCVxLJk=",
      "url": "_content/Blazorise/validators/DateTimeMaskValidator.js"
    },
    {
      "hash": "sha256-RvdrNjHB3Z79Jf1QB/v3rjA4ib41PS+fjetwFdNiJuw=",
      "url": "_content/Blazorise/validators/NoValidator.js"
    },
    {
      "hash": "sha256-4ar0+fGtxySKLf8iZAlv7UMfP/0rO43/fn6aJjFYscE=",
      "url": "_content/Blazorise/validators/NumericMaskValidator.js"
    },
    {
      "hash": "sha256-0JfcdT/AH07dbEAVpuaISjcVIZZmz6JaK0kpd2kRHFM=",
      "url": "_content/Blazorise/validators/RegExMaskValidator.js"
    },
    {
      "hash": "sha256-QPixC/RhNy0Sx4ntFHFH0iGj3tNiFkhkh/FDWbau6LE=",
      "url": "_content/Blazorise/vendors/Behave.js"
    },
    {
      "hash": "sha256-1gHexzaXVdeRaNA/1rkPr0sk9Wcyys2XlLgv22akhVM=",
      "url": "_content/Blazorise/vendors/Pickr.js"
    },
    {
      "hash": "sha256-dThViewRMpe+cFQ1zAZsNzQkylfewW7Ac5p0vxV/m8E=",
      "url": "_content/Blazorise/vendors/autoNumeric.js"
    },
    {
      "hash": "sha256-TuPGTy1RSyKjfSGGz7VXOVYYoW3nhlFnCiVxIxtci88=",
      "url": "_content/Blazorise/vendors/flatpickr.js"
    },
    {
      "hash": "sha256-0guaW7kt/WFpp8o6esUyNY5+Wm0/Jk0sgZGfiLlpIV0=",
      "url": "_content/Blazorise/vendors/floating-ui-core.js"
    },
    {
      "hash": "sha256-cxuZSSJUtLW1W9nVAnm5EiMlDJ34kSIUSNACDrLG6OI=",
      "url": "_content/Blazorise/vendors/floating-ui.js"
    },
    {
      "hash": "sha256-+mZGO/MfY1p0zmJh0VuKN/1cSevolIfLp+1p4yqRST0=",
      "url": "_content/Blazorise/vendors/inputmask.js"
    },
    {
      "hash": "sha256-UYwEFy4Dt94x8agDo+K5rAAynsteCUPA/G2UQCHEvyM=",
      "url": "_content/Blazorise/vendors/jsencrypt.js"
    },
    {
      "hash": "sha256-T669X4q1yaJ6B5DN8/9KsgTvI8XU++i+SKw0jqyF7cg=",
      "url": "_content/Blazorise/vendors/popper.js"
    },
    {
      "hash": "sha256-E+LUjqfR7dS8pbN72SD0gJxBccFzMa7ZTfkInVjDPqU=",
      "url": "_content/Blazorise/vendors/sha512.js"
    },
    {
      "hash": "sha256-oFOgmI6gjvkRx+rnGkC9+YEUKgYYpmyzeC72X6tjqfM=",
      "url": "_content/Blazorise/vendors/tippy.js"
    },
    {
      "hash": "sha256-kJXKqRCleT/Jk1wJUhUu24r2LAA7IWVYmdoENizE38M=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-pihy/29gBvlw6VVc/n+q5FgpOBnObADFWDdS5SEJKgQ=",
      "url": "_framework/Blazor-ApexCharts.6svvilbkck.wasm"
    },
    {
      "hash": "sha256-IQcxgjVrStWq9rSFTVUZWKOuvDgieCRFNF1PAl2+exA=",
      "url": "_framework/Blazorise.Bootstrap.zzph793o0v.wasm"
    },
    {
      "hash": "sha256-0UGj5IC7BFsKvU55MJqoi4dBRPuZt3tjqHaObLswjK8=",
      "url": "_framework/Blazorise.Bootstrap5.tduggdifmq.wasm"
    },
    {
      "hash": "sha256-0wS9m7Bses6jhw3OoPmhZQRhkfuzFNhRFSklq01ARjY=",
      "url": "_framework/Blazorise.Charts.5ufw3474qu.wasm"
    },
    {
      "hash": "sha256-o1LYB/2BWo1g/oZkFm4upyHDPoDeKCakXLy9d4Nfdu4=",
      "url": "_framework/Blazorise.Icons.FontAwesome.vhmroo7f7a.wasm"
    },
    {
      "hash": "sha256-cwZ2JjZXwvbaPnMO5TRbPjB5RCR6BTjFabvKtE/wTnQ=",
      "url": "_framework/Blazorise.Licensing.5q2r77toij.wasm"
    },
    {
      "hash": "sha256-yunXxKyzorhaSz/4ajbPsQMPbbAUGI673nq8XI/6lIQ=",
      "url": "_framework/Blazorise.m9nkbb8nyy.wasm"
    },
    {
      "hash": "sha256-8KaSQQKzkSLxYo0ViQQKmvLoat2EMnYmC4Q2Ft6zU7M=",
      "url": "_framework/Lambda2Js.s11rboxncj.wasm"
    },
    {
      "hash": "sha256-zPFXeeGdBs4UPBpbat5NEN4EI/Ig1eV4jzbgb6Pcurc=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.gf26ou9jj9.wasm"
    },
    {
      "hash": "sha256-WShaslVUH4uKLh3hXazSn9XwD8JhJmLeMj4QyajtDhc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.rrohwkxxx2.wasm"
    },
    {
      "hash": "sha256-iRpIK6WbESudNMb4Gn8EobxIwBTS9CaF2sk8Lf6gpxo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.n0ihslit6r.wasm"
    },
    {
      "hash": "sha256-IRk+L9wTVGOzFRwpwwhlLur5WHJtJijw6DkitrbVWP8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.76kzmc18wd.wasm"
    },
    {
      "hash": "sha256-NyfmmSqZ0GXgcnGt9vZIttunoj480cGXerqGtk5Av8I=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.hegb9isbhu.wasm"
    },
    {
      "hash": "sha256-JOecUyFY5LH5Ac/aS4GR6lcugK/Gq+yc54PvybHGKtA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.soaj85mrfq.wasm"
    },
    {
      "hash": "sha256-uxsAoGDTMmkORHVq8kyh/BB0ebk1uKUb97qNJkwZeRA=",
      "url": "_framework/Microsoft.AspNetCore.Components.v3fd2n5hlr.wasm"
    },
    {
      "hash": "sha256-7aF2mNWJfo77SuzVCYtFmsKVOD4FWb1IN11+LHFnZJQ=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.ru07a9pbbl.wasm"
    },
    {
      "hash": "sha256-9uB/7IFSiKE1yWAQ/EFaS3ub/zf5RJXVK6CMmA7mxhY=",
      "url": "_framework/Microsoft.CSharp.qzjvm9hz38.wasm"
    },
    {
      "hash": "sha256-MHoSC8gnZ0nA1bVW091JRZr/s2NYEDI8VN8URMn7l1A=",
      "url": "_framework/Microsoft.Extensions.Configuration.8aq32nyru9.wasm"
    },
    {
      "hash": "sha256-mh2B1gZ/I/aYfwOasdEe8ZDqDumYuSAf16lKpo7O9Cc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.avw86po9nh.wasm"
    },
    {
      "hash": "sha256-e7iUAwUzfveYLikEwhIr5W4bq6oZF1dfz3PGtP2cZSQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.ls8wraf4rs.wasm"
    },
    {
      "hash": "sha256-Tes3PpZnhlFELJ4sR5mk3LIBSBgSVxaOtm6Stta0RkU=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.t8hgoms9l8.wasm"
    },
    {
      "hash": "sha256-X8yu6Be+ZHHzhDFDdP9RXu+aMsQKscEedJsYUzy2QII=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.d1nka2rlr8.wasm"
    },
    {
      "hash": "sha256-qAVwtobE69vbIkwz/K0lf2/iKMJIA/xXT1gA4Ezrjs8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.srbzsu00e3.wasm"
    },
    {
      "hash": "sha256-a1XNvsqstcjxdiOZ9hMAVw1tDm61bzzn67tAES/BnT8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.hpstk8kub5.wasm"
    },
    {
      "hash": "sha256-gOAgDZqFIP4yzKNPRiHDHY+1bIVn6KmMs7z9TdlGA90=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.c9bmyvcsky.wasm"
    },
    {
      "hash": "sha256-IoLwBSPt+bWr4eGsg2DsqsYvvc8BzTBGq50pfg/u2KE=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.uwkkfuzktm.wasm"
    },
    {
      "hash": "sha256-XK4yjhBp9ksL7h6/ebqAR1HCPn2J3GpEbf9c57HcAI8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.kqqw7ug7ce.wasm"
    },
    {
      "hash": "sha256-it/ygGigzRU3ywKNWGR0Gl2nsIrJWHV/HC4P5v37uQk=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.mh53tttw45.wasm"
    },
    {
      "hash": "sha256-qIytzULqOsu5wQ9kRbESlZbqf91VCam4aH1AEY0B8dI=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.0i562wdyma.wasm"
    },
    {
      "hash": "sha256-33dCsYa2t4MgXnqenpZSDZiaVBt4LbMTfUUhedIsUiI=",
      "url": "_framework/Microsoft.Extensions.Http.Polly.bh3pa407mf.wasm"
    },
    {
      "hash": "sha256-RDRSZfgSj5nBaq5QnxLaqMzp8SKSyNN0mxLwbXBNKCY=",
      "url": "_framework/Microsoft.Extensions.Http.km5diny1k4.wasm"
    },
    {
      "hash": "sha256-lISZ2evbuKBWFb8LlXP3CMikApVVFJqf5TPtJx78eoY=",
      "url": "_framework/Microsoft.Extensions.Logging.4of5ydne24.wasm"
    },
    {
      "hash": "sha256-/o20MY3V1aj5IvIOgosGTivRxDe2Bf2ReAnh8UJezgk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.mnju7fj288.wasm"
    },
    {
      "hash": "sha256-ehjyGp2amBo1B9vQ3//ywaKCwMu83SYMV7YIilU6G9k=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.e34jhrwynt.wasm"
    },
    {
      "hash": "sha256-foMpU3/ofkt/ZrWQc7UZkpA82JZ66I5r+U5dp7NcMCE=",
      "url": "_framework/Microsoft.Extensions.Options.ug6nnndcge.wasm"
    },
    {
      "hash": "sha256-EQ2SeJgaUjRLYUVamIO8veqo0ULa8a/smS1fHkPruaY=",
      "url": "_framework/Microsoft.Extensions.Primitives.hkjc7m6x3e.wasm"
    },
    {
      "hash": "sha256-w+WvmTYZ9xv2XDrEoF7buW47/o7dUeKdnYWKUgyFEkU=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lao5cp8gqq.wasm"
    },
    {
      "hash": "sha256-DmHnC9ymHQnTh0MVm4HX6gjjWpxkDYwTq2KqksxY+ZA=",
      "url": "_framework/Microsoft.JSInterop.uxfxoah9jv.wasm"
    },
    {
      "hash": "sha256-tT8Mx7IXGkD6vZZAtEi9ZzXf+A2nPkCn9cStfF49D8w=",
      "url": "_framework/Microsoft.VisualBasic.Core.790ssxljcz.wasm"
    },
    {
      "hash": "sha256-mF3L2/zWdzCiZgxEqWZq47WPANCts8RfZuGD/Q+uuX8=",
      "url": "_framework/Microsoft.VisualBasic.o05ci7346e.wasm"
    },
    {
      "hash": "sha256-EiWyemclMi1PgUArdIfN4wrpSvL30PbdGpW3hK7Kujg=",
      "url": "_framework/Microsoft.Win32.Primitives.iclgtmwg3j.wasm"
    },
    {
      "hash": "sha256-5E1OW2jOP0sC2xDrg1wPVU+AT40zGS6wfHzblMd1JmY=",
      "url": "_framework/Microsoft.Win32.Registry.ozmyxl3pzt.wasm"
    },
    {
      "hash": "sha256-+DjUTQjXSh1w/MNq5yHC9l9Y7GiV+WQBmMvMjd4+OnM=",
      "url": "_framework/Newtonsoft.Json.8gze232pcy.wasm"
    },
    {
      "hash": "sha256-LWJN5PUlmyuUO5U/g3JioL184LenNn5SOVaZ5FmvqcU=",
      "url": "_framework/Newtonsoft.Json.Bson.bau63na29o.wasm"
    },
    {
      "hash": "sha256-bqX9l2dLJ0m0IilNsXvbO14i9Lx0oDeudAGIsS3kEAw=",
      "url": "_framework/Polly.Extensions.Http.aamf4ift6v.wasm"
    },
    {
      "hash": "sha256-nqtTJO4ORk0a9aj8aiYClicrbMc0aZVi3iA34o/Gznc=",
      "url": "_framework/Polly.ivrqkyor03.wasm"
    },
    {
      "hash": "sha256-WjRTeSJEprZ9HBzk4BKplWRIfgrhjPFFDj+UqA8cVrQ=",
      "url": "_framework/System.AppContext.69xw87cqtg.wasm"
    },
    {
      "hash": "sha256-3j3RX7ELLcTNnVgSKL/nQIF30UYXsmMglc/qhGDs75s=",
      "url": "_framework/System.Buffers.m3enj6d62j.wasm"
    },
    {
      "hash": "sha256-K4wiHreDko1fwGzNJheQz9DbCK4V+HUsGQuyuuSquBs=",
      "url": "_framework/System.Collections.Concurrent.7xcnvnvfe7.wasm"
    },
    {
      "hash": "sha256-M/IZfhSsVdt09D9vqi6G+5jmZwKwnpmoj80YhEqNmio=",
      "url": "_framework/System.Collections.Immutable.3gjnwcmszy.wasm"
    },
    {
      "hash": "sha256-cNYWf2QGLEhkh5iK07aMMe5Bcs3eS4UlF8l4/vYhrak=",
      "url": "_framework/System.Collections.NonGeneric.wor57912gd.wasm"
    },
    {
      "hash": "sha256-Gt60ISo8L7jUrF1s550/CSgDvoJ7dcEd1P2muR6WDf8=",
      "url": "_framework/System.Collections.Specialized.6wmcrebyv4.wasm"
    },
    {
      "hash": "sha256-EBK0m0SABO/x1RRnnH5vP69b6zfq2LdCOsOsVDlov64=",
      "url": "_framework/System.Collections.k7eocx66k5.wasm"
    },
    {
      "hash": "sha256-V2T0KVH8VVLw7L85hEgfeaEos1rJhvnYB3u9FIZmUPU=",
      "url": "_framework/System.ComponentModel.1er4s7iwhi.wasm"
    },
    {
      "hash": "sha256-XGeWQDi2iTnZBVzhCrGlittZAIdfUhrIbXRnpkhb028=",
      "url": "_framework/System.ComponentModel.Annotations.w9cu337rh7.wasm"
    },
    {
      "hash": "sha256-5g8drc35NLzT0Lyub4LojCNKfvdPO4MnDV+MM2bNL3Y=",
      "url": "_framework/System.ComponentModel.DataAnnotations.q4j9ve32z8.wasm"
    },
    {
      "hash": "sha256-En/nVKvNuqUTMc1tzWAdlyIevyeAxBtvc4xM9/MJuAc=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.6j6cjcru2p.wasm"
    },
    {
      "hash": "sha256-q/oKLBvJG+geL5EyEHp2eXfgNhZVr/Zhi/FntEAwhQ0=",
      "url": "_framework/System.ComponentModel.Primitives.nl2ixrxcp7.wasm"
    },
    {
      "hash": "sha256-ChgNcQf/RB+Co51s8Ugh60AgiwQs/7h4eYcY4iFZoAY=",
      "url": "_framework/System.ComponentModel.TypeConverter.yl273bvsmt.wasm"
    },
    {
      "hash": "sha256-rQCrGK5wobGc3Hp+4oCT/3luV4uZhhHYY64s3eyYINo=",
      "url": "_framework/System.Configuration.zc0ilizti4.wasm"
    },
    {
      "hash": "sha256-JLvbJQwbzXWLPcuAap3mP40auHr8SAFCdxwW1pvdg9Q=",
      "url": "_framework/System.Console.c87d7usqgw.wasm"
    },
    {
      "hash": "sha256-4uVaLtcvzHPn/4NQ7CAdQS5YvEXAgPlK20cTabVAzLc=",
      "url": "_framework/System.Core.eovbtmx9ej.wasm"
    },
    {
      "hash": "sha256-3oNnHAFrSjx4eG9cQad/ekNH1TDn5kh/h81TGTrzFBc=",
      "url": "_framework/System.Data.Common.i3ihuk6o50.wasm"
    },
    {
      "hash": "sha256-CW8OHC3xmWQsCWFz/ONW6I+pGnoGJghtsPvfovvn4Lk=",
      "url": "_framework/System.Data.DataSetExtensions.drrqo6rbpu.wasm"
    },
    {
      "hash": "sha256-pQefGURvVYnJfB4r1bqwjICELx1/PcaO4X6DE2GmHqA=",
      "url": "_framework/System.Data.rwg7jt2c7s.wasm"
    },
    {
      "hash": "sha256-dP0J9QfyU79fjnu4R7pBWqThLAGFljYB+iZ4qD3my2g=",
      "url": "_framework/System.Diagnostics.Contracts.8nb2a3iwdt.wasm"
    },
    {
      "hash": "sha256-UIoVmBzWqal6zr8bfGgH31ABpMy0RtSpAH410LivWxw=",
      "url": "_framework/System.Diagnostics.Debug.shhvs5h51d.wasm"
    },
    {
      "hash": "sha256-eX6QyBIHo7DpqgE+zLLvIUsRKS0F3lcMDGJqx/bH+i0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.v6xqrblgfp.wasm"
    },
    {
      "hash": "sha256-IE/nm8ILVpMsi9M5b/wHjl+hZ1mq8A80cBfrrDfIPQo=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.4f475qbfex.wasm"
    },
    {
      "hash": "sha256-ctAOTzX6sRJrYmm6L1IR1d/peO/41z15KSvX5bD3CXA=",
      "url": "_framework/System.Diagnostics.Process.6bewsddwg5.wasm"
    },
    {
      "hash": "sha256-HlK7hkrTKLL/GWZNaNxHpN0Cq+jfxoRmxyQC6V8GNFY=",
      "url": "_framework/System.Diagnostics.StackTrace.ailofr3xg4.wasm"
    },
    {
      "hash": "sha256-wkyd1vycGAFwraqTTFaliZHidaWRULoFLWTA9TXUIUc=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.y0i2x9wcx8.wasm"
    },
    {
      "hash": "sha256-QyVSWNwVykbkYBK62ib1bVRMckJ4VrKwTh20cbUKHaI=",
      "url": "_framework/System.Diagnostics.Tools.xv4owfjv5r.wasm"
    },
    {
      "hash": "sha256-FvewqTBqpx1JkQzNIlyVGAqjci3QNBorU1FMP20383A=",
      "url": "_framework/System.Diagnostics.TraceSource.qvejter5tv.wasm"
    },
    {
      "hash": "sha256-S79g7dYCezxrMalL8q9cDdrXnsjWlJ8eEfkkAoQiCUw=",
      "url": "_framework/System.Diagnostics.Tracing.vjwiyy6ngo.wasm"
    },
    {
      "hash": "sha256-J1BzaGslK1b041LKijGsbgEXo2hz+TV5aDeEDluHRLM=",
      "url": "_framework/System.Drawing.Primitives.1qn7cohx2f.wasm"
    },
    {
      "hash": "sha256-C5aie7lp5Olga/uM7+TxmJqlNqhGVdM0EnPkKvIPFzY=",
      "url": "_framework/System.Drawing.rccadbk353.wasm"
    },
    {
      "hash": "sha256-VP+X94eHpfTx68Wy9SWPtuwtQ9dkw22EM4flKmBKgR4=",
      "url": "_framework/System.Dynamic.Runtime.ck56btm7q7.wasm"
    },
    {
      "hash": "sha256-RnU0WJm52F6WBniZO9X8zK2po0C5dbfx9vtPn1JhTKk=",
      "url": "_framework/System.Formats.Asn1.y2x54k0om0.wasm"
    },
    {
      "hash": "sha256-E66k4j+pTfrMejgFxpuLwnZTMZmDPu9nRcYQBaUAhcI=",
      "url": "_framework/System.Formats.Tar.twtiqgxl95.wasm"
    },
    {
      "hash": "sha256-o0Mo6b0POvywYBd38GFQHye+xiFLumyyjq1QCfcP93s=",
      "url": "_framework/System.Globalization.Calendars.toi3bgped5.wasm"
    },
    {
      "hash": "sha256-a4TI7+ZAA4OWD0AVG1hk5BftP5bS+9NGN3gFf5j/pxI=",
      "url": "_framework/System.Globalization.Extensions.tmi9prr4h8.wasm"
    },
    {
      "hash": "sha256-/gSgB6F7rRQvM+yjhAiINKW0c5yWWJMv2oRozGSqRck=",
      "url": "_framework/System.Globalization.adywr1r9bu.wasm"
    },
    {
      "hash": "sha256-Z5CDkVkjwuT22en4OfKGOsKF8xmn3rnzpFC/sOV/s98=",
      "url": "_framework/System.IO.Compression.Brotli.xqt090n7fe.wasm"
    },
    {
      "hash": "sha256-sJvT36EkkK+tNHmjJH8bmlN6cc4/jQSoj8DmZvRK7Z0=",
      "url": "_framework/System.IO.Compression.FileSystem.8a6edcjpz8.wasm"
    },
    {
      "hash": "sha256-ZPFVvgHctccilTSA+aw7ptEIFAGSsK8OU2sqiWJnMtE=",
      "url": "_framework/System.IO.Compression.ZipFile.0h0gr0lp29.wasm"
    },
    {
      "hash": "sha256-U7uFERAexPQqzVn1O+j2wXcvfd0Z3iME+2TQyMw2VqE=",
      "url": "_framework/System.IO.Compression.r2vc7bedoc.wasm"
    },
    {
      "hash": "sha256-xlSHVtG4unz+dcAA0hhkA8Q0lHuSQNO66T03cCsDetU=",
      "url": "_framework/System.IO.FileSystem.AccessControl.q8w04p4lkj.wasm"
    },
    {
      "hash": "sha256-akbvdz+Bzo/lxy7wn9exx5ZIibbC/7Y613KCYeKsDcQ=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.21bnaui2ta.wasm"
    },
    {
      "hash": "sha256-Wn6JJ3fC/tyCdCf8U8Z3CQEyS0acc7ycnOnWrefm7jc=",
      "url": "_framework/System.IO.FileSystem.Primitives.uai8nn8fsl.wasm"
    },
    {
      "hash": "sha256-RYe+cfmj735vWHHAgyNpM1DTaho0ZkUPa/PMmJv0BPM=",
      "url": "_framework/System.IO.FileSystem.Watcher.lohvs8m8cz.wasm"
    },
    {
      "hash": "sha256-HCMsOFWOEfPI6DaByEf17abUsIu2I7kmee0hPmPuVkk=",
      "url": "_framework/System.IO.FileSystem.ci93a4roia.wasm"
    },
    {
      "hash": "sha256-s25hyXaZ5uk3hvmTwFbYpW5EPpdPxcJDp/7iXCS2r7k=",
      "url": "_framework/System.IO.IsolatedStorage.z0ha6lo11a.wasm"
    },
    {
      "hash": "sha256-vocytJ/l6QXPGlQrcB0KK2aIqpQEzrohL48uGjcMQfA=",
      "url": "_framework/System.IO.MemoryMappedFiles.2kvmbxu1mj.wasm"
    },
    {
      "hash": "sha256-20bG9oqY9dw5UXZJXXmWUeUZKZagM6yyrp4uDMaWb3Y=",
      "url": "_framework/System.IO.Pipelines.frsl2omn10.wasm"
    },
    {
      "hash": "sha256-voPLo6JDiECfeenKIEHmLqv/qKABH50wlsdzt9VpyBI=",
      "url": "_framework/System.IO.Pipes.AccessControl.mrms2eewly.wasm"
    },
    {
      "hash": "sha256-6FSiZxMZg9eihpN7EPbxlmzXVzgpqbvSo/hr1TQWiKA=",
      "url": "_framework/System.IO.Pipes.wadz9p1757.wasm"
    },
    {
      "hash": "sha256-ry3N3SYpf2rcSD2fElLG2SmgLYCNER5QGACExKUqMMA=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.5nttvixer4.wasm"
    },
    {
      "hash": "sha256-RnP1Vw/g7QXgQo0beNIQRUpJqm+Zdq+a9n5FD5FVhmg=",
      "url": "_framework/System.IO.ujr9p4dm3m.wasm"
    },
    {
      "hash": "sha256-J44ZD0+Abo5j1u9alQBOQSEv5QQwiuS9Bl11Hr1CyEg=",
      "url": "_framework/System.Linq.Expressions.n4kp8xrm7p.wasm"
    },
    {
      "hash": "sha256-wWwYZYO4PBLunTlKxgkgNrYf4LaRNLW1+ttyQNXRBrA=",
      "url": "_framework/System.Linq.Parallel.fk2xwub03l.wasm"
    },
    {
      "hash": "sha256-deNp98KQYru39BdpEEDVGJr5IgIF71vs8Awif2Roa18=",
      "url": "_framework/System.Linq.Queryable.npjr4r7hxc.wasm"
    },
    {
      "hash": "sha256-k/4vfd1gi0Igp02C6gO37W17kpB9ayyZ3n+wWGyw8j0=",
      "url": "_framework/System.Linq.bi0wcqo6qy.wasm"
    },
    {
      "hash": "sha256-6FFdAcFh1bU5oYaZPM8IawVzH2yuLUhZAUqU1H8GsNM=",
      "url": "_framework/System.Memory.80u0qc3eyv.wasm"
    },
    {
      "hash": "sha256-QECYQXIPSpm25jMOGqooUqHf1Yu9qZ1mqDu3jkixqZc=",
      "url": "_framework/System.Net.Http.Json.0slem1275q.wasm"
    },
    {
      "hash": "sha256-upfNQvzSBsRS8XQA3pe+w7ZM9LtVYVsPMBNSPQz0Za8=",
      "url": "_framework/System.Net.Http.md1bswe7tc.wasm"
    },
    {
      "hash": "sha256-XGqG7bZyewH40zhfml+ZSw2KL5zNmfw7FoZRvUxDBPg=",
      "url": "_framework/System.Net.HttpListener.o3q2lkyykw.wasm"
    },
    {
      "hash": "sha256-4RMFpDXMQyT4qhsQLpbiPCm7eDc2s5ialcC51zd/E3Q=",
      "url": "_framework/System.Net.Mail.r12nqubh1e.wasm"
    },
    {
      "hash": "sha256-/J0+R/iVUQOPv3kT6RUER/flByKyNSXkLo3/rUjOjaQ=",
      "url": "_framework/System.Net.NameResolution.wd9u3p7alm.wasm"
    },
    {
      "hash": "sha256-6IaMhqDl2A7hEWhohc+1Z7Rx9i05lnI1KrfQ47bru9A=",
      "url": "_framework/System.Net.NetworkInformation.wadfcrb4ng.wasm"
    },
    {
      "hash": "sha256-O2Mmei6iNrk3UtuXBlZNTo5s5nVxgj1Ftoo1lspinMo=",
      "url": "_framework/System.Net.Ping.j6du5khfyp.wasm"
    },
    {
      "hash": "sha256-exdvtma5pQ0+bTFtKFkM9UO1DoT/3/CoMtJ6alliEA8=",
      "url": "_framework/System.Net.Primitives.rog0rqelo4.wasm"
    },
    {
      "hash": "sha256-i1CgSScIo50IN6eB/MzFEuOfHqMlJ77qe40TWRmUQJM=",
      "url": "_framework/System.Net.Quic.bk3iyzagtw.wasm"
    },
    {
      "hash": "sha256-urm2huryfgDrvMw0MGd4tFTNfOidly7YLXdx4+mcNFE=",
      "url": "_framework/System.Net.Requests.yh0vmblcre.wasm"
    },
    {
      "hash": "sha256-mMC9pPuuxznXU4BiItV1X9W/yHL8ZcEuwyASbTRYcQo=",
      "url": "_framework/System.Net.Security.sr0ifz1ms7.wasm"
    },
    {
      "hash": "sha256-doTQB6fcYtyjN6poV0Fvvx0XvZvQ1FRelIayR3E1L38=",
      "url": "_framework/System.Net.ServicePoint.ii3nejp2xq.wasm"
    },
    {
      "hash": "sha256-9g7OESQMxFOhjJ3p+3DvempeXJkpt3ONvKlRglrSLS0=",
      "url": "_framework/System.Net.Sockets.2qi573rk74.wasm"
    },
    {
      "hash": "sha256-PsuK5MvKhguJJhG51ATXDsDvK6M388PkYmbY8SZdEBc=",
      "url": "_framework/System.Net.WebClient.6zl2dfdj87.wasm"
    },
    {
      "hash": "sha256-2pW9PMX+twt0ZEHlTyZiaS1AR32v/iuqAceMlhjzuwA=",
      "url": "_framework/System.Net.WebHeaderCollection.6toxm9clu5.wasm"
    },
    {
      "hash": "sha256-nZ6euTt/hGeNQZkfE4SNOefGQl252QLYMJj1PloKQ3I=",
      "url": "_framework/System.Net.WebProxy.zg8yqia6rm.wasm"
    },
    {
      "hash": "sha256-JUJbedL/7FtaJfk+Sz8Xq895L2A2G6sdox4mj9LWuvo=",
      "url": "_framework/System.Net.WebSockets.9v4eqey3ns.wasm"
    },
    {
      "hash": "sha256-0+eqZDo58c3c6D35LjE+ckKj1xd7lvHte+2fkTz8+VQ=",
      "url": "_framework/System.Net.WebSockets.Client.5ujv6fwlc7.wasm"
    },
    {
      "hash": "sha256-fR539S+bwSXVgp+3uaS1Q5U84NeEd9CRanORSCHCB2A=",
      "url": "_framework/System.Net.j0rb8fmqum.wasm"
    },
    {
      "hash": "sha256-yXp7bBpXpcNlAwM9S1VLSKU9L6AdD4WmhOHJ8rV2NxM=",
      "url": "_framework/System.Numerics.90814qnc69.wasm"
    },
    {
      "hash": "sha256-XfJBerh7sgb/6eKD6r6reMq8HWeYTih4l9cLZLkveeM=",
      "url": "_framework/System.Numerics.Vectors.zkzeaq78be.wasm"
    },
    {
      "hash": "sha256-cT7Oj8MIjjRPWoUXfWFhaX98I8Ja1euVw//7TAFSPFY=",
      "url": "_framework/System.ObjectModel.dpibji9kbk.wasm"
    },
    {
      "hash": "sha256-1OU1YKgOeX1+SJh4arMvQthG0Pk1cugP2GYSbyEBt08=",
      "url": "_framework/System.Private.CoreLib.gdne0axslz.wasm"
    },
    {
      "hash": "sha256-ODMTKHXU2ugKU1zWA3W35hBlu7RmiWiklaTSElV4hwc=",
      "url": "_framework/System.Private.DataContractSerialization.s7udpkt4m4.wasm"
    },
    {
      "hash": "sha256-NuUtr7v6SQnKsfv7AUGRWcM+y8fRpE7SdlWCxivyhqA=",
      "url": "_framework/System.Private.Uri.akbheibrxy.wasm"
    },
    {
      "hash": "sha256-Ohm3Iudl/LUOQvmww9wb/G9w6rb5MwQzSW/BmFI/nJE=",
      "url": "_framework/System.Private.Xml.2mep7n6yu4.wasm"
    },
    {
      "hash": "sha256-9dDKJVGHfc0p0O5c0ynqp+OIXcPyfaB4xh6KpoHa5UM=",
      "url": "_framework/System.Private.Xml.Linq.pznij1v87w.wasm"
    },
    {
      "hash": "sha256-Z7qYjBufHmw6kUBZchuFwV/8AhekqZ2u1JjPdNWsLc0=",
      "url": "_framework/System.Reflection.DispatchProxy.rz2l0yjrdh.wasm"
    },
    {
      "hash": "sha256-YsZ2JGMqM9ErPnTRKB418kzA1XeYpRIkEuVzwy0uTmM=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.ul9zb0sw6s.wasm"
    },
    {
      "hash": "sha256-gXgVmt9a/3wj1Xxib98T50wKaq67A7LO2sxhIJ7RVV8=",
      "url": "_framework/System.Reflection.Emit.Lightweight.h81142zbp5.wasm"
    },
    {
      "hash": "sha256-2UPd6E8YpQSfLB3NyFXZTMdWvg0n7BOtHnNxWOp76vw=",
      "url": "_framework/System.Reflection.Emit.r3y2j8tf69.wasm"
    },
    {
      "hash": "sha256-tpIvL/S9/SB9javHKbsHL5fRcK9d3v4jH2cWRRzb2NI=",
      "url": "_framework/System.Reflection.Extensions.q3j8knzs2x.wasm"
    },
    {
      "hash": "sha256-dseZsLBukxyc0//EfBZle+byG75lKChrUH30tET8uSQ=",
      "url": "_framework/System.Reflection.Metadata.act044hy0s.wasm"
    },
    {
      "hash": "sha256-JVg2JH92HegcOa0XYIW4JEA9CdQXoDf30w7RglipcDY=",
      "url": "_framework/System.Reflection.Primitives.5os0vainak.wasm"
    },
    {
      "hash": "sha256-6ZM+J2vC1ewu4NrAJ3pDfXjcBEXOkFcdwZCKwFYRYD0=",
      "url": "_framework/System.Reflection.TypeExtensions.5p21krjfml.wasm"
    },
    {
      "hash": "sha256-GfOsodQI4RuaJ/V5w8bS9fY5s6fAc/+hC+C+OhPOSU8=",
      "url": "_framework/System.Reflection.vmr4sf3lia.wasm"
    },
    {
      "hash": "sha256-RrOMh7Fflmijq+kQ00jqw+hn6YKo96iZKgXYaWaY6vA=",
      "url": "_framework/System.Resources.Reader.6dewscbl2z.wasm"
    },
    {
      "hash": "sha256-ULqJuTD0YgEEEQ6ME7LwaGEt4eO6NlKHmoWRQLiCkik=",
      "url": "_framework/System.Resources.ResourceManager.kvuwqbbhvv.wasm"
    },
    {
      "hash": "sha256-kSrZhHz5ja8JJXR7INSF31lKb7SxvyM1rY5YayEpsYA=",
      "url": "_framework/System.Resources.Writer.dpk7abvmmf.wasm"
    },
    {
      "hash": "sha256-ZR4rw0u/Tw7fNJarv8ioL1H7Zo/cUO3yEw1Hy6YO1z4=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.ja2wapc8ts.wasm"
    },
    {
      "hash": "sha256-2xr1KCucnlhi+ib0AjfdE3a3Z04EoMvadyD7Nlbe1x8=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.b05mwug83r.wasm"
    },
    {
      "hash": "sha256-eDV+IESTRl9cmrIPccQ/fXMf6PvKgUIDxs5hvpl5ZW4=",
      "url": "_framework/System.Runtime.Extensions.wmorg0bfhl.wasm"
    },
    {
      "hash": "sha256-zB8IfdNrsbp7xC+qDTzx4hTgzN/gnXnqlFuPorF2KbE=",
      "url": "_framework/System.Runtime.Handles.wry3x7xspd.wasm"
    },
    {
      "hash": "sha256-KDoINFDRHJ8Pu5o1C1wBZI9SIda7PKLmI92LfK/VEIk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.gm4fhld22q.wasm"
    },
    {
      "hash": "sha256-IntHanIWOD/SnrE+/goZbhkKVnO1iL9VNK861YMZiiM=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.u8mdnzb9vy.wasm"
    },
    {
      "hash": "sha256-dG7GAKHV18AMGSeSQSV5kd3WieLFUB22pbNllS3npew=",
      "url": "_framework/System.Runtime.InteropServices.wtgp5mxw1c.wasm"
    },
    {
      "hash": "sha256-WOCZnZQcexMnzsRTroMKLUyq/pq3J2RJqta+QanxkCM=",
      "url": "_framework/System.Runtime.Intrinsics.gi0f477zy4.wasm"
    },
    {
      "hash": "sha256-fO8rRwIMpfZDabxoEYHjXA9AsDnmlART3gQkHg9417w=",
      "url": "_framework/System.Runtime.Loader.cot9lfqma4.wasm"
    },
    {
      "hash": "sha256-zBdVFvwwLKbv0DjVXFxri+BAsnJKz2dWVhQYeUFeHL4=",
      "url": "_framework/System.Runtime.Numerics.g9u8d42zol.wasm"
    },
    {
      "hash": "sha256-pYfVu7e9S5oGlsuuEssQVg86KJMiYI+Si78gZbHxU6U=",
      "url": "_framework/System.Runtime.Serialization.5wmrv335ba.wasm"
    },
    {
      "hash": "sha256-TBSKF9cAB8dfUpoI2ph//Xiy8Vi5NYb/E3qwccD8+Ws=",
      "url": "_framework/System.Runtime.Serialization.Formatters.8lhd6xdb7k.wasm"
    },
    {
      "hash": "sha256-04xP70ZHRi5gpY+QtvRHGHuD2wqMMDUeRtOu9b7oPJE=",
      "url": "_framework/System.Runtime.Serialization.Json.z0nxu35yve.wasm"
    },
    {
      "hash": "sha256-91fq6cGgCr9G+mlI+su/+6Uf/vJnjsxtMmGGybgSMjc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.fqg5015ygf.wasm"
    },
    {
      "hash": "sha256-2qTmn0CJYKEr0Ula7cxW5UYUCZQGwznx0R3A6RwVrE8=",
      "url": "_framework/System.Runtime.Serialization.Xml.u3xtkxm1k9.wasm"
    },
    {
      "hash": "sha256-JLkVxBaclpeLsQ5jyDuBsosw6/tNfPcSJWx9/v4oxuM=",
      "url": "_framework/System.Runtime.grclbqoc80.wasm"
    },
    {
      "hash": "sha256-uHj8uCh7gsZJRIiF023EV4GXlZf8BLL2zf6mRUEZY0g=",
      "url": "_framework/System.Security.88p4kjqbas.wasm"
    },
    {
      "hash": "sha256-oSt7GqHO5j0KeGCDv1+2Su1MH3h463L7e5ubBQIzaow=",
      "url": "_framework/System.Security.AccessControl.pe5x2sidyv.wasm"
    },
    {
      "hash": "sha256-kaulak1+AChe7FZMy9qT8DS3Dp5SY2lNCFhjaif/X+c=",
      "url": "_framework/System.Security.Claims.l7kx3xked0.wasm"
    },
    {
      "hash": "sha256-RCXyoYas3cGys3td0sG0HXP8Q/pI8BuaYU38BRgpT2M=",
      "url": "_framework/System.Security.Cryptography.Algorithms.8lolrkmttk.wasm"
    },
    {
      "hash": "sha256-aVoAx87qwSo1iTzQO2QDDCl1tEgK1tPhQtUTWhgYWwY=",
      "url": "_framework/System.Security.Cryptography.Cng.xy0ipfnjac.wasm"
    },
    {
      "hash": "sha256-y71Kg/w5QM+RIchoXukhVxo9x8OewOEoMs6hP7sFIm8=",
      "url": "_framework/System.Security.Cryptography.Csp.tqrnaro11n.wasm"
    },
    {
      "hash": "sha256-wRkq0w5ZiZoPw3mSWtMUEc6KaZ7AWQgmerc5leDnYtM=",
      "url": "_framework/System.Security.Cryptography.Encoding.dxlnja37bj.wasm"
    },
    {
      "hash": "sha256-vptjZ6FgtgBPauumyfJ48l86KdO7HnQ8MTeWkwX59jw=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.uk9h1gfypt.wasm"
    },
    {
      "hash": "sha256-nDAcS03VxsiiIXZU6Zc48rZooO3R/mdo0cnqGFwPbaM=",
      "url": "_framework/System.Security.Cryptography.Primitives.wxqgbuw71m.wasm"
    },
    {
      "hash": "sha256-vkTUHeFSGAgA8+FmseRWLnZ6itnUbq60eMHaRGsS9yQ=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.m2ilqf86hj.wasm"
    },
    {
      "hash": "sha256-JomzotZvKj3Dswxo92Ft8TgIBTE+bSBHUHzSO94CyzI=",
      "url": "_framework/System.Security.Cryptography.qo6wt0x95a.wasm"
    },
    {
      "hash": "sha256-qVN02cdyGwF/laDjXCMxeUXo8c3+HMtpbtvt4lf7wKY=",
      "url": "_framework/System.Security.Principal.Windows.ldo9869o7b.wasm"
    },
    {
      "hash": "sha256-aS9n//VXqMcPHVRugjy8oRiV7Qy0GeJt0CXDYjUGwLI=",
      "url": "_framework/System.Security.Principal.l5y65m8m2t.wasm"
    },
    {
      "hash": "sha256-nHx+cm5lbMBhBIY54L1XsTe0OX2XgrjBket4/hldcVc=",
      "url": "_framework/System.Security.SecureString.c87gsi9tp6.wasm"
    },
    {
      "hash": "sha256-2sEk/ECeFrjUa73QWh/9S+yk1E+57Y4MQ4GVirnvwSs=",
      "url": "_framework/System.ServiceModel.Web.64psc55341.wasm"
    },
    {
      "hash": "sha256-bVu/ZX1HolbMf8KYDRkTB6uEvBDL2BWiD1Sr+z7fjdI=",
      "url": "_framework/System.ServiceProcess.j0wagton1u.wasm"
    },
    {
      "hash": "sha256-neeJgRHQESp95X4VYmYau9ADi9gRfzLdVrZD+20Lr5k=",
      "url": "_framework/System.Text.Encoding.CodePages.17ak399x9u.wasm"
    },
    {
      "hash": "sha256-RzEmC3krVLJ9ntQtDPb5biOo+VMRJQ9yXNpUldEUCgo=",
      "url": "_framework/System.Text.Encoding.Extensions.31quu9rg9b.wasm"
    },
    {
      "hash": "sha256-MxhxRj/3AtAjRI+NFH3TE1wDRsHrk2v16O9FV6yZGvA=",
      "url": "_framework/System.Text.Encoding.ruq9wa2av8.wasm"
    },
    {
      "hash": "sha256-iIgCDUHNaA7yZoPd5RuId5obZjiurjXH0SWZuCC2Ffs=",
      "url": "_framework/System.Text.Encodings.Web.ktp7ll9vtg.wasm"
    },
    {
      "hash": "sha256-Gsd26Q1hfumhMJqtRnFWa2Pa5UH/GYfZnG6r0f3f6k4=",
      "url": "_framework/System.Text.Json.ablk86rw37.wasm"
    },
    {
      "hash": "sha256-q31YShSwQTVUMkC6qPLL1cnolkqwgzaZpc1FyGUv8Bo=",
      "url": "_framework/System.Text.RegularExpressions.j6wzkfckdc.wasm"
    },
    {
      "hash": "sha256-Qns/dqTUF7fi5EGOXEeB7CtMsLhDYV3Q+hDRgg9OpRM=",
      "url": "_framework/System.Threading.Channels.eotefikzu6.wasm"
    },
    {
      "hash": "sha256-Rk+MnPULAL/QWvLXQmRK/KQ78DstK3HKj++2//yHJfE=",
      "url": "_framework/System.Threading.Overlapped.qsv3dgk98d.wasm"
    },
    {
      "hash": "sha256-3p9vchw1uDGQfZ6IKA2Aad61OGaKHJDpSHfx1xFffy0=",
      "url": "_framework/System.Threading.Tasks.Dataflow.qux3elp3sq.wasm"
    },
    {
      "hash": "sha256-6a4BSm0nYOWOSiERCmoNDZrFWTFZtesahBeD0sG+Zco=",
      "url": "_framework/System.Threading.Tasks.Extensions.bz6v4y1bgr.wasm"
    },
    {
      "hash": "sha256-weCM97M0KzlvPfFgYLMYqH/amjcQobpW4qlZL3qxo4k=",
      "url": "_framework/System.Threading.Tasks.Parallel.pia6qfjdvy.wasm"
    },
    {
      "hash": "sha256-K3c/ZIRTSn0oh1TmAg8UwOACCWFTQE0NYxB+3eFoaQQ=",
      "url": "_framework/System.Threading.Tasks.zmf0gmcpmv.wasm"
    },
    {
      "hash": "sha256-iPMgw0rb/TzX741+abHRk7NbjO0UOglDram06lov+VI=",
      "url": "_framework/System.Threading.Thread.k53q2qtn4x.wasm"
    },
    {
      "hash": "sha256-c12BCOrRh3kc02i1rTPs93xFibEd8h3usb6B0qvgeWg=",
      "url": "_framework/System.Threading.ThreadPool.vtcexxwpo3.wasm"
    },
    {
      "hash": "sha256-f+FrWYx/21P3Y9NQ7Nqnd3vHSh3V7mpfUh9yFGQh6wA=",
      "url": "_framework/System.Threading.Timer.5bvshcz8rs.wasm"
    },
    {
      "hash": "sha256-5vw+LhiGIokAb9t63BXU11cpyu2frC81SvsrWbUixvU=",
      "url": "_framework/System.Threading.mghm3mgo9q.wasm"
    },
    {
      "hash": "sha256-ZAqca2tkqMy6m4t15kYxaz6IJq9TwpbleftIIh24yq0=",
      "url": "_framework/System.Transactions.0vkshbqlor.wasm"
    },
    {
      "hash": "sha256-bhoU1a5vQrWuSKJVb+I4gc9eFzSZc7w4S+Hnuetxl1s=",
      "url": "_framework/System.Transactions.Local.upfcz2s4al.wasm"
    },
    {
      "hash": "sha256-r8gRxNTnP1GwHsOms7P8xf8UZzdH6qfICNkcGRIZhyg=",
      "url": "_framework/System.ValueTuple.96vy1hi31v.wasm"
    },
    {
      "hash": "sha256-mH31oNYw5+UG49dSlm838uP1UfXQGtpAsCVyz848FfY=",
      "url": "_framework/System.Web.HttpUtility.crconwjg8e.wasm"
    },
    {
      "hash": "sha256-GruUFtvDlkfkAm3+9ubzpIlckp0tVds/U4BTtZ/uT38=",
      "url": "_framework/System.Web.i52kdwx1wz.wasm"
    },
    {
      "hash": "sha256-bTs5ogTfks55oP4Jbq1P0aiVrOQzsupL8G9KgznMnQ8=",
      "url": "_framework/System.Windows.pxvni61c5f.wasm"
    },
    {
      "hash": "sha256-nuyYbM7wJPWXqp3bQ5b+hxJYWd3snVgE108h4ZBqcEI=",
      "url": "_framework/System.Xml.Linq.qe9nkopg6h.wasm"
    },
    {
      "hash": "sha256-u956/ME4lyctNDenNsnhDYVGaMAyDbkGT3p1WRqN8fk=",
      "url": "_framework/System.Xml.ReaderWriter.7tqo9y1j7t.wasm"
    },
    {
      "hash": "sha256-Usq+mk/8/uKUboQSDMewX4BodqyEN1MImmkHWGFWxJA=",
      "url": "_framework/System.Xml.Serialization.m25ww1xmlb.wasm"
    },
    {
      "hash": "sha256-qS25A4gDSTa0aOaka7XW3TuTJ2FQaDMw+tHAlkelEmY=",
      "url": "_framework/System.Xml.XDocument.b3qpy0ywdq.wasm"
    },
    {
      "hash": "sha256-gsrp2UsBOpo6DVsZu4ARBsWCm3JQPuNVXUQ+okp6R0A=",
      "url": "_framework/System.Xml.XPath.6zhyzqh2n6.wasm"
    },
    {
      "hash": "sha256-b6b4ScTgYcA196w5Fu47Y93t3RS0WF43M2zkxQjqZV4=",
      "url": "_framework/System.Xml.XPath.XDocument.7m1x4rd2b8.wasm"
    },
    {
      "hash": "sha256-ZuximY5G3R2IKy2kSInT0cpkNg1c1D1N+CiupL8+ZNo=",
      "url": "_framework/System.Xml.XmlDocument.q8ihts3lf6.wasm"
    },
    {
      "hash": "sha256-sEDsdRnHVbBNVz6bccuTQVGhvbDDG4FjUvsAs9JYWWk=",
      "url": "_framework/System.Xml.XmlSerializer.0sc0ourwbb.wasm"
    },
    {
      "hash": "sha256-1mUMJnO1XU6Oh74bHbj/CMBgsf1njzDYzjSkw3ZehSA=",
      "url": "_framework/System.Xml.ev8p5vqcxx.wasm"
    },
    {
      "hash": "sha256-9pVBpQZbLwdDpJKVVwy9ZdzXAR66hfWXuyiJRIkhaUM=",
      "url": "_framework/System.uey7cwmupp.wasm"
    },
    {
      "hash": "sha256-txIkYmz9QU/MJzTShOvmYTQXOoacbq4yxs2KqNr+OFA=",
      "url": "_framework/University.128iw1nvg7.pdb"
    },
    {
      "hash": "sha256-nmXdOPPm//lfJOJoqnJdSK8E75j/dvt4cRSB7ZrKvhY=",
      "url": "_framework/University.uou5n5pcf5.wasm"
    },
    {
      "hash": "sha256-BgyZxTgdU9rIYlNC9ZMiMjnvBAJSL0eQH8Y87o1M+q4=",
      "url": "_framework/WindowsBase.ag32297siy.wasm"
    },
    {
      "hash": "sha256-iyt+jF0ltWhsqodXyjh507MbsnjOx1Fg3NGMX19c3JU=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-XoL4KXKUiNydxBQ0q7b/0gDsgsuq8oac0YMVUnGkfRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-hZR53FKJSxjnxgvKrH7p+D7FLbv31p/Msx6rLNsW5Ps=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-1UPiprzN3JhPftx3be7XEMaYlUN+chRF41CuttiWVtQ=",
      "url": "_framework/dotnet.native.1p93gcv9fh.js"
    },
    {
      "hash": "sha256-Yaw09m1FVxsROJ5Sa9f6SmuJebQT0b3hrKQIbo6qm5A=",
      "url": "_framework/dotnet.native.9msu8ucn2h.wasm"
    },
    {
      "hash": "sha256-j0o3Jd43TEt7CL/kaSWnO8IALA8Zgoa3fcyaWDAVIyM=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-ilTXrnUF4HKbIAFVIYlRmX3ryKNZpGUObkWMF0n2Kcg=",
      "url": "_framework/dotnet.runtime.qrl1fuqt3c.js"
    },
    {
      "hash": "sha256-Mx0VsGdPho2zM/5S9YwT7b8atC7yYD1hxzwRJlbdaCk=",
      "url": "_framework/fl_front.xn3xau1bcr.pdb"
    },
    {
      "hash": "sha256-mk/a3A6k0CvB3Z8Y48BJ3TWCRIiMYid5Jx9cqCbtIWc=",
      "url": "_framework/fl_front.yllsglhjp0.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-/aFxOaPc1iTNlJw0z4/RGEMD0nzl4qVE3SF4wMsLgp0=",
      "url": "_framework/mscorlib.vt9pwshhot.wasm"
    },
    {
      "hash": "sha256-nD1KqAI5YYz+YohqHaZ5EmXi7Eq9Uy9sUknnI8sj1AM=",
      "url": "_framework/netstandard.or41gtprh3.wasm"
    },
    {
      "hash": "sha256-5vfLhofM8THsDOLuLsNeWBNzqjRAgEXYpJOeqKqnZyU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-w1r5kNbOWVRNp5o1V0h8A2zrtSgIKVm1oIa7iXXXUhs=",
      "url": "fl_front.styles.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-rUfiMWb5LlrJhGbgrx4I+kn3WavVMJta5YGw1+RfBNk=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-N4yGGMd7zV0RgmQlDoR6ott/iNZoGoYPew90MmHyXrY=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-aAyjWnQIyPuHjzyt7eZNG2LjCh7XSwngeL1EUE/QlD4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-UWLp78PxMPqcHQq9lSd7coWRrs9YeM3ysrql9XV+6/0=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-/MRQWHCYf+yjVe/W/fJafiHjBxut/eMiN//9FCedG44=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-ccAQnOIGg9h1LigUgSU18CerlRGGQn05GBuq6xlF2a4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-ETITG5IS1mY4Ypil8YBlR+Wv7VpALI9ERnrRZOnBKRc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-uYpiIMSYKKv+hPFX64RAo6G/7OO5tPCBaYkgStvMWWI=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-VwgYIRBYMOPGKufbnSOgiasd2n5M+uANurCbrhaYcBw=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-8MIhZdePOLye8LacHFTjw/MblR5H+iWo3BZdvTXv6NY=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-iKUn9V+r5BV8FFvEANQKRdqFtJ6QyaFgSAM+kJ5jjRQ=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
